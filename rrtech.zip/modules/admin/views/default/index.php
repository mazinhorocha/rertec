<div class="admin-default-index">

    <div class="container">
        <div class="row">
            <div class="col-4 mb-3">
                <a href="/admin/pages" class="btn btn-outline-secondary btn-lg btn-block">
                    <i class="fa fa-sliders"></i>
                    Páginas
                </a>
            </div>
            <div class="col-4 mb-3">
                <a href="/admin/produtos" class="btn btn-outline-secondary btn-lg btn-block">
                    <i class="fa fa-cart-arrow-down"></i>
                    Produtos
                </a>
            </div>
            <div class="col-4 mb-3">
                <a href="/admin/servico" class="btn btn-outline-secondary btn-lg btn-block">
                    <i class="fa fa-flash"></i>
                    Serviços
                </a>
            </div>
            <div class="col-4 mb-3">
                <a href="/admin/banner" class="btn btn-outline-secondary btn-lg btn-block">
                    <i class="fa fa-picture-o"></i>
                    Banner
                </a>
            </div>
            <div class="col-4 mb-3">
                <a href="/admin/depoimentos" class="btn btn-outline-secondary btn-lg btn-block">
                    <i class="fa fa-bullhorn"></i>
                    Depoimentos
                </a>
            </div>
            <div class="col-4 mb-3">
                <a href="/admin/nossos-clientes" class="btn btn-outline-secondary btn-lg btn-block">
                    <i class="fa fa-users"></i>
                    Clientes
                </a>
            </div>
            <div class="col-4 mb-3">
                <a href="/admin/post" class="btn btn-outline-secondary btn-lg btn-block">
                    <i class="fa fa-pencil-square-o"></i>
                    Posts
                </a>
            </div>
        </div>
    </div>

</div>
