<?php

namespace app\modules\admin\controllers;

use app\models\Media;
use app\models\Metafields;
use Yii;
use app\models\Pages;
use app\models\PagesSearch;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\helpers\Inflector;
use yii\web\Response;

/**
 * PagesController implements the CRUD actions for Pages model.
 */
class PagesController extends Controller
{
    public $enableCsrfValidation = false;

    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Pages models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new PagesSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Pages model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('update', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Pages model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Pages();

        if ($model->load(Yii::$app->request->post())) {

            $model->custom = isset($model->custom) ? serialize($model->custom) : null;

            $model->save();
            return $this->redirect(['update', 'id' => $model->id]);
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Pages model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post())) {

            $model->custom = isset($model->custom) ? serialize($model->custom) : null;

            if($model->save()) :
                if(isset($model->add_metafield)){
                    $meta = new Metafields();
                    foreach ($model->add_metafield as $item) {
                        $meta->page_id = $model->id;
                        $meta->name = $item['name'];
                        $meta->key = Inflector::slug($item['key'], '_');
                        $meta->value = $item['value'];
                        $meta->save();
                    }
                }
                if(isset($model->metafields)){
                    foreach ($model->metafields as $item) {
                        if(($meta = Metafields::findOne($item['id'])) !== null){
                            $meta->value = $item['value'];
                            $meta->save();
                        }
                    }
                }
            endif;

            //return $this->redirect(['update', 'id' => $model->id]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Pages model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Pages model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Pages the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Pages::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }

    public function actionUpload(){
        Yii::$app->response->format = Response::FORMAT_JSON;
        $session = Yii::$app->session;

        $uploaddir = "storage/";
        $filename = md5(time() . $_FILES['file']['name']) . '.jpg';
        $uploadfile = $uploaddir . basename($filename);

        if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadfile)) {

            $model = new Media();
            $model->name = $filename;
            $model->link = $uploadfile;
            $model->save();

            print_r($model->hasErrors()); die;

        } else {
            echo "Possible file upload attack!\n";
        }
    }
}
